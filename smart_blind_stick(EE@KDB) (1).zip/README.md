# **Ultrasonic Distance Alert System**  
**Author**: 2022EEB105 SUPRIYO_ROY  
**Board**: Raspberry Pi Pico (MicroPython)  
**Simulation Platform**: [Wokwi](https://wokwi.com)  

---

## **📝 Project Description**  
This project demonstrates an **Ultrasonic Distance Alert System** using a **Raspberry Pi Pico**, an **HC-SR04 Ultrasonic Sensor**, a **buzzer**, and an **LED**. The system measures the distance of nearby objects and triggers an audible alarm (buzzer) along with a visual indicator (LED) when an object comes too close.  

### **🎯 Key Features**  
- Real-time distance measurement using an **HC-SR04 ultrasonic sensor**.  
- **Buzzer & LED activation** when an object is within a predefined threshold (20 cm by default).  
- **Serial monitor output** for debugging and distance monitoring.  
- **Fully customizable** thresholds, alarm duration, and buzzer frequency.  

---





## **💻 MicroPython Code Overview**  
The main logic is implemented in `code.py`:  

### **Key Functions**  
1. **`measure_distance()`**  
   - Sends a **10µs trigger pulse** to the HC-SR04.  
   - Measures the **echo pulse duration** and converts it to distance (cm).  

2. **`trigger_alarm()`**  
   - Activates the **buzzer (1kHz tone)** and **LED** for **0.5 seconds**.  

3. **`main()`**  
   - Continuously checks distance.  
   - Triggers alarm if object is within `DISTANCE_THRESHOLD`.  
   - Prints distance readings to the **Serial Monitor**.  

### **Customizable Settings**  
```python
DISTANCE_THRESHOLD = 20  # (cm) - Adjust detection range
BUZZER_FREQ = 1000      # (Hz) - Change alarm tone pitch
ALARM_DURATION = 0.5    # (sec) - Modify alarm duration
```

---

## **🚀 How to Simulate in Wokwi**  
1. **Copy the `diagram.json`** into Wokwi’s editor.  
2. **Upload `code.py`** to the Raspberry Pi Pico.  
3. **Run the simulation** and observe:  
   - **Serial Monitor** for distance readings.  
   - **Buzzer & LED** activation when an object is too close.  
4. **Adjust the ultrasonic sensor’s distance slider** to test different scenarios.  

---


```
